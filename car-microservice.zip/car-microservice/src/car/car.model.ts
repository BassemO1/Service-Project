import { Schema,Document,model } from 'mongoose';

export interface Car extends Document {
  readonly type: string;
  readonly brand: string;
  readonly carmodel: string;
  readonly engine: string;
  readonly TopSpeed: string;
}
export const UserSchema = new Schema({
    type: {
      type: String,
      required: true,
    },
    brand: {
      type: String,
      required: true,
    },
    carmodel: {
      type: String,
      required: true,
    },
    engine: {
      type: String,
    },
    TopSpeed: {
      type: String,
      required: true,
    },
  });
  
  export const CarModel = model<Car>('UserSchema', UserSchema);