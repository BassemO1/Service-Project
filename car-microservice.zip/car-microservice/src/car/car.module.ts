import { Module } from '@nestjs/common';
import { CarController } from './car.controller';
import { CarService } from './car.service';
import { MongooseModule } from '@nestjs/mongoose';
import { UserSchema,CarModel } from './car.model'; // Import the schema


@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Car', schema: UserSchema }]), // Provide ItemModel
  ],
  controllers: [CarController],
  providers: [CarService]
})
export class CarModule {}
