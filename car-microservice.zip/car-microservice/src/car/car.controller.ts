import { Controller, Get, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { CarService } from './car.service';
import { Car } from './car.model';
@Controller('car')
export class CarController {
    constructor(private readonly userService: CarService) { }
    @Post()
    async create(@Body() createUserDto: Car): Promise<Car> {
        return this.userService.create(createUserDto);
    }

    @Get()
    async findAll(): Promise<Car[]> {
        return this.userService.findAll();
    }
    @Get(':id')
    async findOne(@Param('id') id: string): Promise<Car> {
        return this.userService.findOne(id);
    }

    @Put(':id')
    async update(@Param('id') id: string, @Body() updateUserDto: Car): Promise<Car> {
        return this.userService.update(id, updateUserDto);
    }

    @Delete(':id')
    async remove(@Param('id') id: string): Promise<any> {
        return this.userService.delete(id);
    }
}
