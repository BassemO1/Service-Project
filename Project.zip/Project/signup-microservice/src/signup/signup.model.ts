// src/items/signup.model.ts
import { Schema,Document,model } from 'mongoose';

export interface signup extends Document {
  readonly first_name: string;
  readonly last_name: string;
  readonly id: number;
  readonly email?: string;
  readonly password: string;
  
}

export const signupSchema = new Schema({
  first_name: {
    type: String,
    required: true,
  },
  last_name: {
    type: String,
    required: true,
  },
  id: {
    type:Number,
    required: true,
  },
  email: {
    type: String,
  },
  password: {
    type: String,
    required: true,
  },
});

export const signupModel = model<signup>('signupSchema', signupSchema);