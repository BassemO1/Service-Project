import { Injectable,Inject } from '@nestjs/common';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { signup } from './signup.model';

@Injectable()
export class SignupService {
    constructor(@Inject('signupModel') private readonly signupModel: Model<signup>) {}

    async create(user: signup): Promise<signup> {
      const newUser = new this.signupModel(user);
      return await newUser.save();
    }
  
    async findAll(): Promise<signup[]> {
      return await this.signupModel.find().exec();
    }
  
    async findOne(id: string): Promise<signup> {
      return await this.signupModel.findById(id).exec();
    }
  
    async update(id: string, user: signup): Promise<signup> {
      return await this.signupModel.findByIdAndUpdate(id, user, { new: true }).exec();
    }
  
    async delete(id: string): Promise<any> {
      return await this.signupModel.deleteOne({ _id: id }).exec();
    }
}
