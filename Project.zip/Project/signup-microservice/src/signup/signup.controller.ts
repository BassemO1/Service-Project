import { Controller, Get, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { SignupService } from './signup.service';
import { signup } from './signup.model';

@Controller('signup')
export class SignupController {
    constructor(private readonly signupService: SignupService) { }
    @Post()
    async create(@Body() createSignupDto: signup): Promise<signup> {
        return this.signupService.create(createSignupDto);
    }

    @Get()
    async findAll(): Promise<signup[]> {
        return this.signupService.findAll();
    }

    @Get(':id')
    async findOne(@Param('id') id: string): Promise<signup> {
        return this.signupService.findOne(id);
    }

    @Put(':id')
    async update(@Param('id') id: string, @Body() updateSignupDto: signup): Promise<signup> {
        return this.signupService.update(id, updateSignupDto);
    }

    @Delete(':id')
    async remove(@Param('id') id: string): Promise<any> {
        return this.signupService.delete(id);
    }

}

