import { Module } from '@nestjs/common';
import { AxiosModule } from '@nestjs/axios'; // Correct import statement
import { LoginController } from './api.controller';
import { LoginService } from './api.service';

@Module({
  imports: [AxiosModule], // Corrected import statement
  controllers: [LoginController],
  providers: [LoginService],
})
export class ApiModule {}
