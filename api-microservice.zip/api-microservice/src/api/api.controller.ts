// api.controller.ts
import { Controller, Get, Post, Put, Delete, Param, Body, HttpException, HttpStatus } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Controller('api')
export class LoginController { // Renamed ApiController to LoginController
  constructor(private readonly httpService: HttpService) {}

  @Get(':id')
  getLoginData(@Param('id') id: string): Observable<any> { // Renamed method to getLoginData
    const observable1 = this.httpService.get(`http://localhost:4010/login/${id}`);

    return observable1.pipe(catchError(this.handleError));
  }

  @Post()
  createLoginData(@Body() loginData: any): Observable<any> { // Renamed method to createLoginData
    const observable1 = this.httpService.post('http://localhost:4010/login', loginData);

    return observable1.pipe(catchError(this.handleError));
  }

  @Put(':id')
  updateLoginData(@Param('id') id: string, @Body() updatedLoginData: any): Observable<any> { // Renamed method to updateLoginData
    const observable1 = this.httpService.put(`http://localhost:4010/login/${id}`, updatedLoginData);

    return observable1.pipe(catchError(this.handleError));
  }

  @Delete(':id')
  deleteLoginData(@Param('id') id: string): Observable<any> { // Renamed method to deleteLoginData
    const observable1 = this.httpService.delete(`http://localhost:4010/login/${id}`);

    return observable1.pipe(catchError(this.handleError));
  }

  private handleError(error: any) {
    if (error.response && error.response.status === 404) {
      throw new HttpException('Resource not found', HttpStatus.NOT_FOUND);
    }
    return throwError(error);
  }
}
