// api.service.ts
import { Injectable, HttpService, HttpException, HttpStatus } from '@nestjs/common';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

// Define an interface for the expected response structure
interface ApiResponse {
  data: any; // Adjust this based on the actual response structure
}

@Injectable()
export class LoginService {
  constructor(private readonly httpService: HttpService) {}

  getLoginData(id: string): Observable<any> {
    return this.httpService.get(`http://localhost:4010/login/${id}`).pipe(
      catchError(this.handleError),
      map(response => (response.data as ApiResponse).data),
    );
  }

  createLoginData(loginData: any): Observable<any> {
    return this.httpService.post('http://localhost:4010/login', loginData).pipe(
      catchError(this.handleError),
      map(response => (response.data as ApiResponse).data),
    );
  }

  updateLoginData(id: string, updatedLoginData: any): Observable<any> {
    return this.httpService.put(`http://localhost:4010/login/${id}`, updatedLoginData).pipe(
      catchError(this.handleError),
      map(response => (response.data as ApiResponse).data),
    );
  }

  deleteLoginData(id: string): Observable<any> {
    return this.httpService.delete(`http://localhost:4010/login/${id}`).pipe(
      catchError(this.handleError),
      map(response => (response.data as ApiResponse).data),
    );
  }

  private handleError(error: any) {
    if (error.response && error.response.status === 404) {
      throw new HttpException('Resource not found', HttpStatus.NOT_FOUND);
    }
    return throwError(error);
  }
}
