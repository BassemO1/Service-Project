// src/items/motor.model.ts
import { Schema,Document,model } from 'mongoose';

export interface Motor extends Document {
  readonly brand: string;
  readonly Model: string;
  readonly horsepower: string;
  readonly topspeed: string;
}

export const MotorSchema = new Schema({
  brand: {
    type: String,
    required: true,
  },
  Modelname: {
    type: String,
    required: true,
  },
  horsepower: {
    type: String,
    required: true,
  },
  topspeed: {
    type: String,
    required: true,
  },
});

export const MotorModel = model<Motor>('UserSchema', MotorSchema);
