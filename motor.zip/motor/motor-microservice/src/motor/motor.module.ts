import { MotorController } from './motor.controller';
import { MotorService } from './motor.service';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { MotorSchema,MotorModel } from './motor.model'; // Import the schema

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Motor', schema: MotorSchema }]), // Provide ItemModel
  ],
  controllers: [MotorController],
  providers: [MotorService]
})
export class MotorModule {}
