import { Injectable,Inject } from '@nestjs/common';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { Motor } from './motor.model';

@Injectable()
export class MotorService {
    constructor(@Inject('MotorModel') private readonly motorModel: Model<Motor>) {}

  async create(user: Motor): Promise<Motor> {
    const newUser = new this.motorModel(user);
    return await newUser.save();
  }

  async findAll(): Promise<Motor[]> {
    return await this.motorModel.find().exec();
  }

  async findOne(id: string): Promise<Motor> {
    return await this.motorModel.findById(id).exec();
  }

  async update(id: string, user: Motor): Promise<Motor> {
    return await this.motorModel.findByIdAndUpdate(id, user, { new: true }).exec();
  }

  async delete(id: string): Promise<any> {
    return await this.motorModel.deleteOne({ _id: id }).exec();
  }
}