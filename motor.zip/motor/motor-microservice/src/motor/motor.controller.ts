import { Controller, Get, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { MotorService } from './motor.service';
import { Motor } from './motor.model';

@Controller('Motor')
export class MotorController {
    constructor(private readonly userService: MotorService) { }
    @Post()
    async create(@Body() createUserDto: Motor): Promise<Motor> {
        return this.userService.create(createUserDto);
    }

    @Get()
    async findAll(): Promise<Motor[]> {
        return this.userService.findAll();
    }

    @Get(':id')
    async findOne(@Param('id') id: string): Promise<Motor> {
        return this.userService.findOne(id);
    }

    @Put(':id')
    async update(@Param('id') id: string, @Body() updateUserDto: Motor): Promise<Motor> {
        return this.userService.update(id, updateUserDto);
    }

    @Delete(':id')
    async remove(@Param('id') id: string): Promise<any> {
        return this.userService.delete(id);
    }


}
