import { Module } from '@nestjs/common';
import { truckController } from './truck.controller';
import { truckService } from './truck.service';
import { MongooseModule } from '@nestjs/mongoose';
import { truckSchema,truckModel } from './truck.model'; // Import the schema



@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'truck', schema: truckSchema }]), // Provide ItemModel
  ],
  controllers: [truckController],
  providers: [truckService]
})
export class truckModule {}

