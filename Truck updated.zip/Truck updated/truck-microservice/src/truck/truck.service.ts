import { Injectable,Inject } from '@nestjs/common';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { truck } from './truck.model';

@Injectable()
export class truckService {
    constructor(@Inject('truckModel') private readonly truckModel: Model<truck>) {}

  async create(truck: truck): Promise<truck> {
    const newtruck = new this.truckModel(truck);
    return await newtruck.save();
  }

  async findAll(): Promise<truck[]> {
    return await this.truckModel.find().exec();
  }

  async findOne(id: string): Promise<truck> {
    return await this.truckModel.findById(id).exec();
  }

  async update(id: string, truck: truck): Promise<truck> {
    return await this.truckModel.findByIdAndUpdate(id, truck, { new: true }).exec();
  }

  async delete(id: string): Promise<any> {
    return await this.truckModel.deleteOne({ _id: id }).exec();
  }
}