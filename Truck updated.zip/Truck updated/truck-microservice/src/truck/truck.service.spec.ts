import { Test, TestingModule } from '@nestjs/testing';
import { truckService } from './truck.service';

describe('TruckService', () => {
  let service: truckService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [truckService],
    }).compile();

    service = module.get<truckService>(truckService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
