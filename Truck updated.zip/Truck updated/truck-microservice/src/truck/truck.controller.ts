import { Controller, Get, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { truckService } from './truck.service';
import { truck } from './truck.model';

@Controller('truck')
export class truckController {
    constructor(private readonly truckService: truckService) { }
    @Post()
    async create(@Body() createtruckDto: truck): Promise<truck> {
        return this.truckService.create(createtruckDto);
    }

    @Get()
    async findAll(): Promise<truck[]> {
        return this.truckService.findAll();
    }

    @Get(':id')
    async findOne(@Param('id') id: string): Promise<truck> {
        return this.truckService.findOne(id);
    }

    @Put(':id')
    async update(@Param('id') id: string, @Body() updatetruckDto: truck): Promise<truck> {
        return this.truckService.update(id, updatetruckDto);
    }

    @Delete(':id')
    async remove(@Param('id') id: string): Promise<any> {
        return this.truckService.delete(id);
    }

}