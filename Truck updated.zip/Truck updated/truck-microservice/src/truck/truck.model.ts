import { Schema,Document,model } from 'mongoose';

export interface truck extends Document {
  readonly type: string;
  readonly brand: string;
  readonly truckmodel: string;
  readonly engine: string;
  readonly topspeed: number;
  readonly fuelcapacity: string; 
  readonly capacityTons: number;
}

export const truckSchema = new Schema({
  type: {
    type: String,
    required: true,
  },
  brand: {
    type: String,
    required: true,
  },
  truckmodel: {
    type: String,
    required: true,
  },
  engine: {
    type: String,
  },
  topspeed: {
    type: Number,
    required: true,
  },
  fuelcapacity: {
    type: String,
  },
  capacityTons: {
    type: Number,
    required: true,
  },
});

export const truckModel = model<truck>('truckSchema', truckSchema);
